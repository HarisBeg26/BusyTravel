package com.backend.business_travel_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessTravelBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessTravelBackendApplication.class, args);
	}

}
