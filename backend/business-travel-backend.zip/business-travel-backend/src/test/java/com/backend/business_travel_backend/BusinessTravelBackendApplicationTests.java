package com.backend.business_travel_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessTravelBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
